sudo echo "deb http://ports.ubuntu.com/ubuntu-ports/ xenial main" | sudo tee /etc/apt/sources.list
sudo echo "deb http://ports.ubuntu.com/ubuntu-ports/ xenial-security main" | sudo tee -a /etc/apt/sources.list
sudo echo "deb http://ports.ubuntu.com/ubuntu-ports/ xenial-updates main" | sudo tee -a /etc/apt/sources.list
sudo echo "deb http://ports.ubuntu.com/ubuntu-ports/ xenial universe" | sudo tee -a /etc/apt/sources.list
sudo echo "deb http://ports.ubuntu.com/ubuntu-ports/ xenial-security universe" | sudo tee -a /etc/apt/sources.list
sudo echo "deb http://ports.ubuntu.com/ubuntu-ports/ xenial-updates universe" | sudo tee -a /etc/apt/sources.list
sudo apt update
sudo apt upgrade
sudo apt install git cmake libleveldb-dev libsnappy-dev libopencv-dev libhdf5-serial-dev
sudo apt-get install --no-install-recommends libboost-all-dev
sudo apt-get install libatlas-base-dev
sudo apt-get install libgflags-dev libgoogle-glog-dev liblmdb-dev

sudo cp mycustom_op.h /usr/local/include/
sudo cp libome.so /usr/lib64
sudo cp libcustom_op_run.so /usr/lib64
echo "after install libome.so, never use libome.so, use libcustom_op_run.so instead"

sudo cp -r google /usr/local/include/
sudo ln -s /usr/lib64/libprotobuf.so.15 /usr/lib/libprotobuf.so
sudo cp libprotoc.so.15.0.0 /usr/local/lib/
sudo ln -s /usr/lib/libprotoc.so.15.0.0 /usr/lib/libprotoc.so.15
sudo ln -s /usr/lib/libprotoc.so.15 /usr/lib/libprotoc.so


sudo cp -r fmt_include/fmt /usr/local/include/
sudo cp -r fmt_cmake/fmt /usr/local/lib/cmake/
sudo cp libfmt.so.6.2.2 /usr/local/lib/
sudo ln -s /usr/local/lib/libfmt.so.6.2.2 /usr/local/lib/libfmt.so.6
sudo ln -s /usr/local/lib/libfmt.so.6 /usr/local/lib/libfmt.so
sudo cp protoc /usr/local/bin/

sudo chmod a+r /usr/lib64/libprotobuf.so.15

echo "export LIBRARY_PATH=$LIBRARY_PATH:/usr/lib64/" >> ~/.bashrc