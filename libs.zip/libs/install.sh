sudo cp -r google /usr/local/include/
sudo ln -s /usr/lib64/libprotobuf.so.15 /usr/lib/libprotobuf.so
sudo cp libprotoc.so.15.0.0 /usr/local/lib/
sudo ln -s /usr/lib/libprotoc.so.15.0.0 /usr/lib/libprotoc.so.15
sudo ln -s /usr/lib/libprotoc.so.15 /usr/lib/libprotoc.so


sudo cp -r fmt_include/fmt /usr/local/include/
sudo cp -r fmt_cmake/fmt /usr/local/lib/cmake/
sudo cp libfmt.so.6.2.2 /usr/local/lib/
sudo ln -s /usr/local/lib/libfmt.so.6.2.2 /usr/local/lib/libfmt.so.6
sudo ln -s /usr/local/lib/libfmt.so.6 /usr/local/lib/libfmt.so

sudo cp protoc /usr/local/bin/